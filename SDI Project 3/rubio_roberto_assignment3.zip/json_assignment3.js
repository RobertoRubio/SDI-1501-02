// Json files

var family = {
    "Blood": [
        {
            "Name"     : "Daniel",
            "Relation" : "Brother",
            "Age"      : 26,
            "Number"   : 2104210108
        },
        
        {
            "Name"     : "Bebette",
            "Relation" : "Mother",
            "Age"      : 52,
            "Number"   : 2105419798
        },
        
        {
            "Name"     : "Roberto",
            "Relation" : "Father",
            "Age"      : 51,
            "Number"   : 21045419998
        },
        
        {
            "Name"     : "Victor",
            "Relation" : "Brother",
            "Age"      : 22,
            "Number"   : 2109993478
        }
    ]
};
var restaurant = {
    "List": [
        {
            "Name"     : "Zio's",
            "Type"     : "Italian",
            "Location" : "North"
        },
        
        {
            "Name"     : "Whataburger",
            "Type"     : "Burgers",
            "Location" : "Central"
        },
        
        {
            "Name"     : "Phonatic",
            "Type"     : "Vietnamese",
            "Location" : "South"
        },
        
        {
            "Name"     : "Franklin's BBQ",
            "Type"     : "BBQ",
            "Location" : "East"
        }
    ]
};